#!/usr/bin/python
# -*- coding: utf-8 -*-

from distutils.core import setup

setup (
    name = 'executorPool',
    version = '1.0.1',
    py_modules = ['executorPool'],
    author = 'wentao.ma',
    author_email = 'wentao.ma13@gmail.com',
    description = 'a threadPool',
)
